#
# hw9pr1.py - Game of Life lab
#
# Name:
#

import random

def createOneRow(width):
    """ returns one row of zeros of width "width"...  
         You might use this in your createBoard(width, height) function """
    row = []
    for col in range(width):
        row += [0]
    return row




















